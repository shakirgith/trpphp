<?php
// header('Access-Control-Allow-Origin: *');
// header('Access-Control-Allow-Credentials: true');
// header('Access-Control-Allow-Methods:POST,GET,PUT,DELETE');
// header('Access-Control-Allow-Headers: content-type or other');
// header('Content-Type: application/json');
//Please create users database inside phpmysql admin and create registerusers tabel and create  `email`, `username`, `add1`, `add2`, `city`, `state`, `zip` fields
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "trp";
// $id     = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// $method = $_SERVER['REQUEST_METHOD'];
 
 
// if ($conn) {
//    echo "Connection Successful";

// } else {

//   // echo "Connection Failed";
//   die("No Connection" . mysqli_connect_error());

// }



?>

