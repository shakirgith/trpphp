


<?php
include('layout/header.php');
?>

<div class="page-heading"><h1>Oops!</h1></div>   
<main id="main" class="site-main mt-0">
       
  <section class="text-center">
    <div class="container">
        <div id="info" class="text-center">
            <div class="errorimg"><span>404</span></div>
            <h1>Page not found</h1>
            <p>We are sorry but the page you are looking for does not exist.</p>
        </div>
    </div>
</section>
</main>

<?php
include('layout/footer.php');
?>