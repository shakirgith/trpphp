
<?php
session_start();
include('layout/header.php');
if(isset($_GET['token'])) {
    $token = $_GET['token'];
    $updatequery = " update register set status='active' where token='$token' ";

}


?>

    